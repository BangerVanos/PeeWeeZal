### Peewee Tables by Zalomov ###

Module just for testing some peewee stuff. What are you going to find here?
